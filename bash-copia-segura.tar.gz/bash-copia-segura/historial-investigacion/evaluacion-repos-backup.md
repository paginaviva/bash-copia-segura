# Evaluación: Repositorios GitHub — Backup ZIP + multi-config + subida externa

> **Fecha:** 2026-05-12  
> **Criterios de evaluación:**
> 1. **Multi-config** — Soporte para múltiples tareas/configuraciones seleccionables (como `backup_manager`)
> 2. **Formato ZIP** — Preferencia por `.zip` sobre `.tar.gz`
> 3. **Subida externa** — Capacidad de enviar copias a servidor externo vía FTP, S3, rsync, scp, etc.
>
> **Fuente de datos:** Repositorios listados en `temp/CdS/repos-bash-zip-backup.md` más análisis individual de cada uno (README + scripts).

---

## Índice

- [1. Evaluación por repositorio](#1-evaluación-por-repositorio)
- [2. Tabla comparativa consolidada](#2-tabla-comparativa-consolidada)
- [3. Repositorios que NO cumplen ninguno de los criterios](#3-repositorios-que-no-cumplen-ninguno-de-los-criterios)
- [4. Análisis de los mejores candidatos](#4-análisis-de-los-mejores-candidatos)
  - [4.1. PlayWitIt/backup_manager (ya en uso)](#41-playwititbackup_manager-ya-en-uso)
  - [4.2. irlemos/robust-shell-backup](#42-irlemosrobust-shell-backup)
  - [4.3. MimoGraphix/bash-backup-on-steroids](#43-mimographixbash-backup-on-steroids)
  - [4.4. mhowen/bash-backup](#44-mhowenbash-backup)
  - [4.5. Zahra282004/shell-backup-rotation](#45-zahra282004shell-backup-rotation)
- [5. Recomendación final](#5-recomendación-final)

---

## 1. Evaluación por repositorio

### 1.1. PlayWitIt/backup_manager

| Criterio | Estado | Detalle |
|---|---|---|
| Multi-config | **Sí** | Múltiples `.conf` en `configs/`, selección interactiva por número |
| ZIP | No | Usa `tar.gz` en archive step, `rsync` para incremental |
| Subida externa | No | No incluye envío a remoto |
| Forma de config | Archivos `.conf` individuales por tarea | |

**Puntos fuertes:** Sistema multi-conf más similar a lo que pides. Ya lo tienes clonado y funcionando.

**Carencias:** Sin subida externa. Usa `tar.gz` en vez de ZIP (pero eso se puede cambiar editando una línea).

### 1.2. irlemos/robust-shell-backup

| Criterio | Estado | Detalle |
|---|---|---|
| Multi-config | **Sí** | Un solo `.conf` con arrays asociativos para múltiples sitios |
| ZIP | No | Usa `tar` comprimido en stream |
| Subida externa | **Sí** | AWS S3 via `aws-cli` con streaming (sin archivos temporales grandes) |
| Backup BD | **Sí** | MySQL via `mysqldump` |
| Restauración | **Sí** | Script `restore_site.sh` interactivo con auto-config de WordPress |
| Alertas email | **Sí** | SSMTP |
| Retención en S3 | **Sí** | Días configurables |
| Idempotente | **Sí** | Salta si ya existe backup del día |

**Puntos fuertes:** Sistema probado para servidores web multi-sitio. Subida a S3 por streaming (eficiente). Incluye restauración asistida. Manejo de errores atómico (limpia parciales en S3 si falla).

**Carencias:** No usa ZIP (tar). Dependencia de AWS (no es FTP genérico). No es multi-conf separado sino un solo archivo con arrays.

### 1.3. MimoGraphix/bash-backup-on-steroids

| Criterio | Estado | Detalle |
|---|---|---|
| Multi-config | **Sí** | Un solo script con arrays de directorios y opciones vía CLI (`--ignore-database`, `--mode`, etc.) |
| ZIP | No | Usa `tar` con `--listed-incremental` |
| Subida externa | **Sí** | Rsync/SCP a servidor remoto via SSH (modos: `local-only`, `remote-only`, `local-remote`) |
| Backup BD | **Sí** | MySQL y PostgreSQL |
| Cifrado GPG | **Sí** | Encriptación con clave pública |
| Retención | **Sí** | Diaria, semanal, mensual con retención configurable |
| Backups incrementales | **Sí** | `tar --listed-incremental` con plan semanal/mensual como full |

**Puntos fuertes:** El más completo en características: backup remoto via rsync/SSH, cifrado GPG, BD múltiples, retención por periodo, incrementales. Modos de operación vía CLI.

**Carencias:** No usa ZIP (tar). No es multi-conf con archivos separados (usa arrays hardcodeados y args CLI). No tiene FTP nativo (solo rsync/SCP sobre SSH).

### 1.4. mhowen/bash-backup

| Criterio | Estado | Detalle |
|---|---|---|
| Multi-config | No | Un solo script con argumentos CLI |
| ZIP | No | Usa `tar` + encriptación GPG |
| Subida externa | Parcial | AWS S3 via `aws-cli` con flag `-b` |
| Cifrado GPG | **Sí** | Cifrado simétrico con keyfile |

**Puntos fuertes:** Encriptación + S3. Simple y directo.

**Carencias:** Sin multi-config. Sin ZIP. Solo S3 (no FTP).

### 1.5. Zahra282004/shell-backup-rotation

| Criterio | Estado | Detalle |
|---|---|---|
| Multi-config | No | Script único con argumentos posicionales |
| ZIP | **Sí** | `zip` nativo, con timestamp y rotación de 5 archivos |
| Subida externa | No | Solo local |

**Puntos fuertes:** El único que genera `.zip` nativo. Simple. Rotación automática.

**Carencias:** Sin multi-config. Sin subida externa. Muy limitado en funcionalidad.

---

## 2. Tabla comparativa consolidada

| Repositorio | Multi-config | ZIP | Subida externa | Backup BD | Cifrado | Retención | Puntuación |
|---|---|---|---|---|---|---|---|
| PlayWitIt/backup_manager | **Sí** | No | No | No | No | No | ★★ |
| irlemos/robust-shell-backup | **Sí** | No | **S3** | MySQL | No | **Sí** | ★★★★ |
| MimoGraphix/bash-backup-on-steroids | **Sí** | No | **rsync/SCP** | MySQL+PG | GPG | **Sí** | ★★★★★ |
| mhowen/bash-backup | No | No | **S3** | No | GPG | No | ★★ |
| Zahra282004/shell-backup-rotation | No | **Sí** | No | No | No | **Sí** | ★ |

---

## 3. Repositorios que no cumplen ninguno de los criterios

Los siguientes repositorios del listado original **no cumplen ninguno** de los tres criterios principales (ni multi-config, ni ZIP, ni subida externa):

| Repositorio | Razón |
|---|---|
| sxnmgxr/backup-script | Una sola config (config.env), tar.gz, sin subida externa |
| dstoyanov153-maker/linux-infrastructure-scripts | Script único, tar/gzip, sin subida |
| kpiris/bcbbr | Solo para Bitwarden, no genérico |
| Real-SSGyt/ParityVault | Tar + PAR2, manual, sin subida |
| bala242006/bash-backup-automation | Script único, sin descripción funcional |
| Jesus-Emmanuel-Jimenez-Carlos/bash-backup-automation | Script único, sin subida |
| negi-manvendra/backup-automation-script | Script único, tar/gzip, sin subida |
| SachiniKalansooriya/bash-backup-automation | Script único, sin subida |
| ericdomin/bash-backup-tool | Script único, sin documentación |
| kubacharzewski/backup-script | Script único, tar, sin subida |
| biprajit007/backup-automation-script | Script único, sin subida |
| l-MONDY-l/linux-backup-automation | Script único, sin subida |
| webservco/ws_backup | Script único, ISPConfig, sin subida externa |
| pkgstore/bash-backup-fs | Script único, solo backup de FS |
| pkgstore/bash-backup-db | Script único, solo backup de BD |
| NeroPRDO/Shell_Backup_Script | Script único, sin subida |
| tomasmark79/safedata | Script único, sin subida |
| CamBlackwell/bashBackups | Scripts locales, sin subida |
| EmanueleSerraiotto/ibm-de-bash-backup | Mini proyecto educacional |
| royungar/Linux_Shell_Backup_Project | Proyecto educacional |

---

## 4. Análisis de los mejores candidatos

### 4.1. PlayWitIt/backup_manager (ya en uso)

**Ventajas:**
- Sistema multi-conf exactamente como te gusta (archivos `.conf` separados, selección interactiva)
- Ya está clonado y configurado
- Código simple y fácil de modificar

**Cómo cubrir sus carencias:**
- **ZIP:** Cambiar `tar -czvf` por `zip -r` en la línea 98 del script (también cambiar extensión de `.tar.gz` a `.zip`)
- **Subida externa:** Añadir post-step con `rclone`, `aws s3 cp`, `curl -T` (FTP), o `scp` al final del script. Se puede hacer por `.conf` añadiendo variables `REMOTE_URL`, `REMOTE_TYPE`, etc.
- **Verificación integridad:** Añadir `zip -T` después de crear el archive
- **Rotación:** Añadir `find` con `-mtime` al final

### 4.2. irlemos/robust-shell-backup

**Ventajas:**
- Sistema multi-sitio via arrays en un solo `.conf`
- Subida a S3 por streaming (muy eficiente, sin disco local)
- Incluye script de restauración interactivo
- Manejo de errores atómico: si falla, limpia los parciales de S3
- Idempotente: salta si el backup del día ya existe
- Exclusión de subdirectorios por sitio

**Desventajas para ti:**
- Dependencia de AWS S3 (no FTP/SCP genérico)
- Un solo archivo de configuración (arrays), no múltiples `.conf` seleccionables
- Usa tar comprimido en stream, no ZIP
- Orientado a servidores web con MySQL

### 4.3. MimoGraphix/bash-backup-on-steroids

**Ventajas:**
- Backup remoto via rsync/SCP sobre SSH (genérico, no requiere S3)
- Cifrado GPG opcional
- MySQL + PostgreSQL
- Retención por periodos (diario/semanal/mensual)
- Backups incrementales con `tar --listed-incremental`
- Plan de backup semanal con full + incrementales diarios

**Desventajas para ti:**
- Configuración hardcodeada en el script (arrays), no archivos `.conf` separados
- Interacción solo via CLI, no hay menú interactivo para seleccionar tareas
- Sin FTP nativo (solo rsync/scp)
- Sin ZIP (tar)
- Complejidad alta comparado con backup_manager

### 4.4. mhowen/bash-backup

**Ventajas:**
- Encriptación GPG simétrica con keyfile
- Subida a S3 via aws-cli
- Logging a servidor remoto

**Desventajas para ti:**
- Sin multi-config
- Sin ZIP
- Sin FTP (solo S3)
- Sin backup de BD

### 4.5. Zahra282004/shell-backup-rotation

**Ventajas:**
- Único que genera ZIP nativo
- Rotación automática (5 archivos)
- Código mínimo y simple

**Desventajas para ti:**
- Sin multi-config
- Sin subida externa
- Sin backup de BD
- Sin verificación de integridad
- Sin logging estructurado

---

## 5. Recomendación final

### Si quieres mantener backup_manager y extenderlo

**Modificaciones necesarias:**

```bash
# 1. Cambiar tar.gz → ZIP en backup_manager.sh (línea del archive)
# Original:
tar -czvf "$ARCHIVE_FOLDER/$ARCHIVE_NAME" ...
# Cambiar a:
zip -r "$ARCHIVE_FOLDER/${ARCHIVE_NAME%.tar.gz}.zip" ...

# 2. Añadir subida externa al final del script
# Ejemplo con rclone (genérico: S3, FTP, SFTP, etc.):
if [ -n "$REMOTE_DEST" ] && command -v rclone &>/dev/null; then
    rclone copy "$ARCHIVE_FOLDER" "$REMOTE_DEST"
fi

# 3. Añadir variables a cada .conf:
# REMOTE_DEST="remote:S3:mibucket/backups"
# REMOTE_TYPE="rclone"  # o "aws" o "ftp" o "scp"
```

**Ventajas:** Ya lo tienes, es simple, la extensión es trivial.

### Si prefieres algo más completo (recomendado si necesitas BD y subida nativa)

**MimoGraphix/bash-backup-on-steroids** + adaptación ZIP:
- Ya tiene subida remota via rsync/SCP
- Ya tiene backup de MySQL y PostgreSQL
- Ya tiene retención diaria/semanal/mensual
- Ya tiene cifrado GPG
- Solo faltaría cambiar `tar` por `zip` (o añadirlo como opción)

### Si necesitas S3 específicamente

**irlemos/robust-shell-backup** es el más robusto para AWS S3 con multi-sitio.

### Tabla resumen de recomendación

| Necesidad | Mejor opción |
|---|---|
| Multi-conf como backup_manager | **PlayWitIt/backup_manager** (ya lo tienes) |
| Subida externa (rsync/SSH genérico) | **MimoGraphix/bash-backup-on-steroids** |
| Subida a S3 | **irlemos/robust-shell-backup** |
| ZIP nativo | **Zahra282004/shell-backup-rotation** (simple) |
| Máxima cobertura (multi-conf + ZIP + subida) | Ninguno existente → **extender backup_manager** |

---

*Análisis generado a partir del código fuente de cada repositorio y sus README. Los repositorios se obtuvieron via `gh search repos` y se verificaron contra sus archivos reales en GitHub.*
