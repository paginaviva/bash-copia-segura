# Guía de uso: sxnmgxr/backup-script

> **Repositorio:** https://github.com/sxnmgxr/backup-script  
> **Análisis:** 2026-05-12  
> **Propósito:** Sistema automatizado de backup Bash con compresión gzip, rotación de logs, guardia de disco, verificación de integridad y programación cron.

---

## Índice

- [1. Descripción general](#1-descripción-general)
- [2. Estructura del proyecto](#2-estructura-del-proyecto)
- [3. Instalación y configuración](#3-instalación-y-configuración)
  - [3.1. Clonar y preparar](#31-clonar-y-preparar)
  - [3.2. Variables de configuración (config.env)](#32-variables-de-configuración-configenv)
- [4. Comandos y ejemplos de uso](#4-comandos-y-ejemplos-de-uso)
  - [4.1. Ejecutar el test suite](#41-ejecutar-el-test-suite)
  - [4.2. Ejecutar backup manual](#42-ejecutar-backup-manual)
  - [4.3. Programar con cron](#43-programar-con-cron)
- [5. Protocolo de copia de seguridad](#5-protocolo-de-copia-de-seguridad)
  - [5.1. Flujo de ejecución](#51-flujo-de-ejecución)
  - [5.2. Verificación de integridad](#52-verificación-de-integridad)
  - [5.3. Rotación y retención](#53-rotación-y-retención)
  - [5.4. Alertas por correo](#54-alertas-por-correo)
- [6. Ejemplo de salida (log)](#6-ejemplo-de-salida-log)
- [7. Sugerencias y mejoras](#7-sugerencias-y-mejoras)
- [8. Referencia rápida](#8-referencia-rápida)

---

## 1. Descripción general

Script Bash de estilo producción que:

- Comprime directorios con **tar + gzip** (formato `.tar.gz`)
- Verifica la integridad del archivo generado
- Monitorea espacio en disco antes de ejecutar
- Rota backups antiguos según días de retención configurables
- Genera logs detallados con timestamp
- Envía alertas por correo opcionales
- Se integra con cron para ejecución programada

---

## 2. Estructura del proyecto

```
backup-script/
├── backup.sh        # Script principal de backup
├── config.env       # Configuración (editar antes de usar)
├── setup-cron.sh    # Instalador interactivo de cron
├── test.sh          # Suite de pruebas
├── logs/
│   ├── backup.log   # Log de ejecuciones (se crea automáticamente)
│   └── cron.log     # Log de salida de cron (se crea automáticamente)
└── README.md
```

---

## 3. Instalación y configuración

### 3.1. Clonar y preparar

```bash
git clone https://github.com/sxnmgxr/backup-script.git
cd backup-script
chmod +x backup.sh setup-cron.sh test.sh
```

### 3.2. Variables de configuración (config.env)

| Variable | Valor por defecto | Descripción |
|---|---|---|
| `BACKUP_SRC` | `/home/$USER/documents` | Directorio a respaldar |
| `BACKUP_DEST` | `/var/backups/myapp` | Directorio donde guardar los backups |
| `BACKUP_EXCLUDE` | `*.tmp` | Patrón de exclusión (glob) |
| `RETENTION_DAYS` | `7` | Días de retención antes de rotar |
| `MIN_SPACE_MB` | `500` | MB mínimos libres requeridos |
| `LOG_FILE` | `./logs/backup.log` | Ruta del archivo de log |
| `ALERT_ENABLED` | `false` | Activar alertas por correo |
| `ALERT_EMAIL` | `you@example.com` | Destinatario de alertas |

Ejemplo de configuración típica:

```bash
BACKUP_SRC="/var/www/html"
BACKUP_DEST="/mnt/backups/mi-sitio"
BACKUP_EXCLUDE="*.log *.tmp node_modules"
RETENTION_DAYS=14
MIN_SPACE_MB=1000
```

---

## 4. Comandos y ejemplos de uso

### 4.1. Ejecutar el test suite

```bash
bash test.sh
```

Verifica: permisos, comandos requeridos (tar, gzip, find, df, date), existencia de directorios, espacio en disco, compresión tar, integridad de archivo, escritura de logs, y disponibilidad de crontab.

### 4.2. Ejecutar backup manual

```bash
bash backup.sh
```

Salida típica:

```
=================================================
  Automated Backup Script
  2026-05-12 10:30:01
=================================================

[INFO]  === Backup job started ===
[INFO]  Available disk space: 12430MB (minimum required: 500MB)
[INFO]  Starting backup: /home/user/documents → /var/backups/myapp/backup_2026-05-12_10-30-01.tar.gz
[INFO]  Backup SUCCESS: backup_2026-05-12_10-30-01.tar.gz (4.2M)
[INFO]  Verifying integrity of: backup_2026-05-12_10-30-01.tar.gz
[INFO]  Integrity check PASSED: backup_2026-05-12_10-30-01.tar.gz
[INFO]  Rotating backups older than 7 days...
[INFO]  No old backups to rotate.
[INFO]  Current backups in /var/backups/myapp:

-rw-r--r-- ... backup_2026-05-12_10-30-01.tar.gz

[INFO]  === Backup job completed ===
```

### 4.3. Programar con cron

```bash
bash setup-cron.sh
```

Menú interactivo:

```
Select backup schedule:
  1) Every day at 2:00 AM       (recommended)
  2) Every 6 hours
  3) Every Sunday at midnight
  4) Custom (enter manually)
Choice [1-4]:
```

El script registra automáticamente la tarea en crontab y redirige salida a `logs/cron.log`.

---

## 5. Protocolo de copia de seguridad

### 5.1. Flujo de ejecución

```
main()
├── check_disk_space()
│   ├── df BACKUP_DEST
│   ├── compara con MIN_SPACE_MB
│   └── aborta si no hay espacio suficiente
├── run_backup()
│   ├── mkdir -p BACKUP_DEST
│   ├── tar -czf (comprime con gzip, excluye patrones)
│   └── mide tamaño del resultado
├── verify_backup()
│   ├── localiza el archivo más reciente
│   └── tar -tzf (lista contenido sin extraer)
├── rotate_backups()
│   ├── find ... -mtime +RETENTION_DAYS
│   └── rm -f de archivos antiguos
├── list_backups()
│   └── ls -lh de los archivos actuales
└── send_alert() (solo en fallo, si activado)
```

### 5.2. Verificación de integridad

Se usa `tar -tzf` para listar el contenido del archivo `.tar.gz` sin extraerlo. Si el comando retorna `$? -eq 0` el archivo se considera íntegro. En caso contrario se envía alerta de CORRUPT BACKUP.

### 5.3. Rotación y retención

`find "$BACKUP_DEST" -name "backup_*.tar.gz" -mtime +"$RETENTION_DAYS" -print0` busca archivos más antiguos que `RETENTION_DAYS` y los elimina. El valor por defecto es 7 días.

### 5.4. Alertas por correo

Condiciones de alerta:
- Disco lleno (`DISK FULL`)
- Fallo de backup (`BACKUP FAILED`)
- Archivo corrupto (`CORRUPT BACKUP`)

Requiere `ALERT_ENABLED="true"` y el comando `mail` disponible en el sistema.

---

## 6. Ejemplo de salida (log)

```
[2026-05-12 02:00:01] [INFO ] === Backup job started ===
[2026-05-12 02:00:01] [INFO ] Available disk space: 12430MB (minimum required: 500MB)
[2026-05-12 02:00:01] [INFO ] Starting backup: /home/user/documents → /var/backups/myapp/backup_2026-05-12_02-00-01.tar.gz
[2026-05-12 02:00:03] [INFO ] Backup SUCCESS: backup_2026-05-12_02-00-01.tar.gz (4.2M)
[2026-05-12 02:00:03] [INFO ] Verifying integrity of: backup_2026-05-12_02-00-01.tar.gz
[2026-05-12 02:00:03] [INFO ] Integrity check PASSED: backup_2026-05-12_02-00-01.tar.gz
[2026-05-12 02:00:03] [INFO ] Rotating backups older than 7 days...
[2026-05-12 02:00:03] [INFO ] No old backups to rotate.
[2026-05-12 02:00:03] [INFO ] Current backups in /var/backups/myapp:
[2026-05-12 02:00:03] [INFO ] === Backup job completed ===
```

---

## 7. Sugerencias y mejoras

### 7.1. Inmediatas (sobre el código actual)

| Sugerencia | Motivo |
|---|---|
| **Usar `rsync` como modo alternativo** | `tar` siempre comprime todo; `rsync + gzip` sería incremental y más rápido para cambios pequeños |
| **Configurar exclusión múltiple vía archivo** | Pasar `--exclude-from=FILE` en lugar de una sola variable permite listas grandes |
| **Añadir backup de base de datos** | Extensión natural: respaldo MySQL/PostgreSQL antes del tar |
| **Notificaciones vía webhook** | Slack/Discord/Telegram son más prácticas que correo SMTP |

### 7.2. Arquitectura / producción

| Sugerencia | Descripción |
|---|---|
| **Subida a S3/S3-compatible** | Añadir `aws s3 cp` o `rclone copy` después de la verificación |
| **Cifrado GPG** | Encriptar el `.tar.gz` antes de moverlo fuera del servidor |
| **Systemd timer en vez de cron** | Más control sobre dependencias, logging y reinicios |
| **Checksum SHA256** | Generar y almacenar un `.sha256` junto a cada backup para verificación futura |
| **Reporte por correo en éxito también** | La función `send_alert` solo se usa en fallo; podría notificar también en éxito |

### 7.3. Seguridad

| Sugerencia | Descripción |
|---|---|
| **Permisos estrictos en BACKUP_DEST** | Asegurar `chmod 600` a los archivos si contienen datos sensibles |
| **No almacenar credenciales en config.env** | Usar variables de entorno o un vault externo |
| **Log sin datos sensibles** | `backup.log` podría exponer rutas; considerar rotación de logs también |

### 7.4. Uso como script independiente

Si se quiere usar sin clonar el repo completo, los archivos mínimos necesarios son:

```
backup-script/
├── backup.sh
├── config.env
└── logs/       (se crea solo si existe el directorio)
```

Ejemplo de instalación rápida:

```bash
mkdir -p ~/backup-script/logs
cd ~/backup-script
wget https://raw.githubusercontent.com/sxnmgxr/backup-script/main/backup.sh
wget https://raw.githubusercontent.com/sxnmgxr/backup-script/main/config.env
chmod +x backup.sh
# editar config.env
bash backup.sh
```

---

## 8. Referencia rápida

```
# 1. Preparar
git clone https://github.com/sxnmgxr/backup-script.git
cd backup-script
chmod +x *.sh

# 2. Configurar
nano config.env
#   BACKUP_SRC="/ruta/a/respaldar"
#   BACKUP_DEST="/ruta/de/backups"

# 3. Probar
bash test.sh

# 4. Ejecutar manual
bash backup.sh

# 5. Programar
bash setup-cron.sh
  # Opción 1: diario a las 2:00 AM (recomendado)

# 6. Ver logs
cat logs/backup.log
cat logs/cron.log
```

---

*Documentación generada a partir del código fuente en https://github.com/sxnmgxr/backup-script (commit único, branch main).*
