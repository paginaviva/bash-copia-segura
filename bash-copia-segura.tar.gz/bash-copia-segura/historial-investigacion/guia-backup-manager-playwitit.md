# Guía de uso: PlayWitIt/backup_manager

> **Repositorio:** https://github.com/PlayWitIt/backup_manager  
> **Análisis:** 2026-05-12  
> **Propósito:** Gestor de backups shell flexible con soporte incremental (rsync), compresión opcional (tar.gz), y múltiples tareas mediante archivos de configuración individuales.

---

## Índice

- [1. Descripción general](#1-descripción-general)
- [2. Estructura del proyecto](#2-estructura-del-proyecto)
- [3. Instalación y configuración](#3-instalación-y-configuración)
  - [3.1. Clonar y preparar](#31-clonar-y-preparar)
  - [3.2. Archivos de configuración (.conf)](#32-archivos-de-configuración-conf)
  - [3.3. Variables de configuración](#33-variables-de-configuración)
- [4. Comandos y ejemplos de uso](#4-comandos-y-ejemplos-de-uso)
  - [4.1. Ejecución básica](#41-ejecución-básica)
  - [4.2. Modalidades de backup](#42-modalidades-de-backup)
  - [4.3. Múltiples tareas](#43-múltiples-tareas)
- [5. Protocolo de copia de seguridad](#5-protocolo-de-copia-de-seguridad)
  - [5.1. Flujo de ejecución](#51-flujo-de-ejecución)
  - [5.2. Backup incremental (rsync)](#52-backup-incremental-rsync)
  - [5.3. Archivado comprimido (tar.gz)](#53-archivado-comprimido-targz)
  - [5.4. Manejo de errores](#54-manejo-de-errores)
- [6. Ejemplo de salida](#6-ejemplo-de-salida)
- [7. Sugerencias y mejoras](#7-sugerencias-y-mejoras)
- [8. Comparativa con sxnmgxr/backup-script](#8-comparativa-con-sxnmgxrbackup-script)
- [9. Referencia rápida](#9-referencia-rápida)

---

## 1. Descripción general

A diferencia de `sxnmgxr/backup-script` que siempre comprime todo con tar, `backup_manager` ofrece dos capas:

1. **Backup incremental** vía `rsync` — solo copia archivos nuevos o cambiados
2. **Archivado comprimido** vía `tar.gz` — opcional, con timestamp

Soporta **múltiples tareas** mediante archivos `.conf` independientes en `configs/`. El usuario selecciona interactivamente qué tarea ejecutar.

---

## 2. Estructura del proyecto

```
backup_manager/
├── backup_manager.sh        # Script principal
├── configs/                 # Carpeta con archivos .conf
│   ├── example.conf         # Plantilla de configuración
│   ├── documents.conf       # Ejemplo: respaldo de documentos
│   ├── pictures.conf        # Ejemplo: respaldo de fotos
├── screenshots/             # Capturas (documentación)
└── README.md
```

No requiere carpetas pre-creadas: el script crea `BACKUP_FOLDER` y `ARCHIVE_FOLDER` automáticamente.

---

## 3. Instalación y configuración

### 3.1. Clonar y preparar

```bash
git clone https://github.com/PlayWitIt/backup_manager.git
cd backup_manager
chmod +x backup_manager.sh
```

### 3.2. Archivos de configuración (.conf)

Cada tarea de backup es un archivo `.conf` dentro de `configs/`:

```bash
cp configs/example.conf configs/mis-documentos.conf
```

### 3.3. Variables de configuración

| Variable | Obligatorio | Descripción |
|---|---|---|
| `SOURCE` | Sí* | Ruta del directorio a respaldar |
| `BACKUP_FOLDER` | No | Destino del rsync incremental (si se omite → solo archive) |
| `ARCHIVE_FOLDER` | No | Destino del tar.gz con timestamp (si se omite → solo backup) |

*\* Al menos SOURCE o ARCHIVE_FOLDER deben estar definidos para que el script tenga algo que hacer.*

Ejemplo típico:

```bash
SOURCE="/home/user/Documents"
BACKUP_FOLDER="/mnt/disk2/incremental_docs"
ARCHIVE_FOLDER="/mnt/disk2/archives"
```

---

## 4. Comandos y ejemplos de uso

### 4.1. Ejecución básica

```bash
./backup_manager.sh
```

Si hay un solo `.conf`:

```
Only one configuration found. Using: documents.conf
Source folder: /home/user/Documents
Backup folder: /mnt/disk2/incremental_docs
Archive folder: /mnt/disk2/archives
Proceed with backup? (y/n)
```

### 4.2. Modalidades de backup

| Config | Qué hace |
|---|---|
| SOURCE + BACKUP_FOLDER + ARCHIVE_FOLDER | rsync incremental + comprime el backup en tar.gz |
| SOURCE + BACKUP_FOLDER (ARCHIVE_FOLDER vacío) | Solo rsync incremental |
| SOURCE + ARCHIVE_FOLDER (BACKUP_FOLDER vacío) | Comprime SOURCE directamente en tar.gz |
| Solo ARCHIVE_FOLDER (SOURCE vacío) | Error: no hay nada que procesar |

### 4.3. Múltiples tareas

Crea varios `.conf`:

```
configs/
├── web.conf        # SOURCE=/var/www/html
├── db_dumps.conf   # SOURCE=/var/backups/mysql
└── photos.conf     # SOURCE=/home/user/Fotos
```

Al ejecutar:

```
Available backup configurations:
[0] web.conf
[1] db_dumps.conf
[2] photos.conf
Select a configuration to run (number):
```

---

## 5. Protocolo de copia de seguridad

### 5.1. Flujo de ejecución

```
backup_manager.sh
├── Busca archivos .conf en configs/
│   ├── 0 archivos → error y sale
│   └── 1 archivo  → lo usa automáticamente
│   └── >1 archivo → menú interactivo
├── source config (carga variables)
├── Valida SOURCE (debe existir si está definido)
├── Confirmación interactiva (y/n)
├── RSYNC incremental (si SOURCE + BACKUP_FOLDER)
│   ├── mkdir -p BACKUP_FOLDER
│   ├── rsync -av --progress (con exclusiones fijas)
│   └── Códigos de salida: 0=ok, 24=archivos desaparecieron (ok)
└── ARCHIVE tar.gz (si ARCHIVE_FOLDER)
    ├── mkdir -p ARCHIVE_FOLDER
    ├── Si existe BACKUP_FOLDER → comprime BACKUP_FOLDER
    │   └── tar -czvf ARCHIVE_FOLDER/<source>_YYYY-MM-DD.tar.gz
    └── Si NO existe BACKUP_FOLDER → comprime SOURCE directo
```

### 5.2. Backup incremental (rsync)

```bash
rsync -av --progress \
  --exclude='*.tmp' --exclude='*.swp' \
  --exclude='*.DS_Store' --exclude='*.log' --exclude='*.bak' \
  "$SOURCE/" "$BACKUP_FOLDER/"
```

- `-a`: modo archivo (preserva permisos, timestamps, etc.)
- `-v`: verbose
- `--progress`: muestra progreso por archivo
- Exclusiones fijas: `*.tmp`, `*.swp`, `*.DS_Store`, `*.log`, `*.bak`
- El código de salida 24 de rsync (archivos que desaparecieron durante la transferencia) se trata como éxito

### 5.3. Archivado comprimido (tar.gz)

```bash
ARCHIVE_NAME="$(basename "$SOURCE")_$(date +%F).tar.gz"
tar -czvf "$ARCHIVE_FOLDER/$ARCHIVE_NAME" -C "$BACKUP_FOLDER" .
```

- Formato: `{nombre_carpeta}_YYYY-MM-DD.tar.gz`
- Siempre crea el archive desde **el contenido** de la carpeta (no incluye la carpeta raíz)
- Si `BACKUP_FOLDER` no existe, comprime `SOURCE` directamente

### 5.4. Manejo de errores

| Condición | Comportamiento |
|---|---|
| `configs/` no existe | Error y sale |
| Sin archivos `.conf` | Error y sale |
| Selección inválida en menú | Error y sale |
| `SOURCE` no existe | Error y sale |
| `SOURCE` y `ARCHIVE_FOLDER` vacíos | Error y sale |
| Rsync falla (código != 0 y != 24) | Error y sale |
| No se puede crear directorio | Error y sale |
| Usuario responde `n` | Sale sin errores (cancelación limpia) |

---

## 6. Ejemplo de salida

```
$ ./backup_manager.sh

Only one configuration found. Using: documents.conf
Source folder: /home/user/Documents
Backup folder: /mnt/disk2/incremental_docs
Archive folder: /mnt/disk2/archives
Proceed with backup? (y/n) y

Running incremental backup with rsync...
sending incremental file list
./
docs/reporte.pdf
fotos/vacaciones.jpg

sent 12.45M bytes  received 876 bytes  24.90M bytes/sec
Rsync completed (some files may have vanished, see warnings above).

Compressing backup folder '/mnt/disk2/incremental_docs' into Documents_2026-05-12.tar.gz...
./
docs/
docs/reporte.pdf
fotos/
fotos/vacaciones.jpg

Backup process completed successfully!
```

---

## 7. Sugerencias y mejoras

### 7.1. Sobre el código actual

| Sugerencia | Motivo |
|---|---|
| **Añadir verificación de integridad post-archive** | `tar -tzf` después de crear el tar.gz para detectar corrupción temprana |
| **Rotación de archives antiguos** | No hay limpieza automática; los tar.gz se acumulan indefinidamente. Añadir `find ... -mtime +N -delete` |
| **Exclusiones configurables por .conf** | Las exclusiones de rsync están hardcodeadas en el script. Moverlas al archivo `.conf` como variable `EXCLUDE_PATTERNS` |
| **Logging con timestamp** | El script solo imprime a stdout/stderr. Añadir `tee -a` a un archivo de log |
| **Modo no-interactivo** | Añadir flag `--non-interactive` o `-y` para usar en cron sin confirmación |

### 7.2. Arquitectura / producción

| Sugerencia | Descripción |
|---|---|
| **Cifrado GPG del archive** | Encriptar el tar.gz antes de almacenarlo fuera del servidor |
| **Subida a S3/rclone** | Después del archive, copiar a destino remoto |
| **Notificaciones** | Slack/Discord/Telegram al finalizar o en error |
| **Systemd timer** | Reemplazar cron para más control sobre dependencias y logging |
| **Respaldo de bases de datos** | Pre-ear: volcado MySQL/PostgreSQL antes del rsync |

### 7.3. Seguridad

| Sugerencia | Descripción |
|---|---|
| **Permisos en archivos .conf** | Pueden contener rutas sensibles; asegurar `chmod 600` |
| **Exclusión de archivos de credenciales** | Añadir `.env`, `*.key`, `credentials.*` a las exclusiones por defecto |

### 7.4. Uso como script independiente

Archivos mínimos necesarios:

```
backup_manager/
├── backup_manager.sh
├── configs/
│   └── mi-tarea.conf
```

Ejemplo de instalación rápida:

```bash
mkdir -p ~/backup_manager/configs
cd ~/backup_manager
wget https://raw.githubusercontent.com/PlayWitIt/backup_manager/main/backup_manager.sh
chmod +x backup_manager.sh
cat > configs/mis-fotos.conf << 'EOF'
SOURCE="/home/user/Fotos"
BACKUP_FOLDER="/mnt/backups/fotos-incr"
ARCHIVE_FOLDER="/mnt/backups/fotos-archives"
EOF
./backup_manager.sh
```

---

## 8. Comparativa con sxnmgxr/backup-script

| Aspecto | sxnmgxr/backup-script | PlayWitIt/backup_manager |
|---|---|---|
| **Enfoque** | Compresión total con tar.gz | Incremental (rsync) + archive opcional |
| **Formato** | `.tar.gz` siempre | `.tar.gz` solo si se configura ARCHIVE_FOLDER |
| **Incremental** | No (siempre comprime todo) | Sí (rsync) |
| **Rotación** | Sí (RETENTION_DAYS) | No |
| **Verificación integridad** | Sí (tar -tzf) | No |
| **Múltiples tareas** | No (una config) | Sí (varios .conf) |
| **Interactivo** | No | Sí (menú + confirmación) |
| **Logging** | Sí (archivo + tee) | Solo stdout |
| **Alertas email** | Sí (opcional) | No |
| **Guardia disco** | Sí (MIN_SPACE_MB) | No |
| **Exclusiones** | Configurable (BACKUP_EXCLUDE) | Fijas en script |
| **Cron** | setup-cron.sh incluido | No incluido (manual) |
| **Complejidad** | Baja | Media |

---

## 9. Referencia rápida

```bash
# 1. Preparar
git clone https://github.com/PlayWitIt/backup_manager.git
cd backup_manager
chmod +x backup_manager.sh

# 2. Crear configuración
cp configs/example.conf configs/mi-proyecto.conf
nano configs/mi-proyecto.conf
#   SOURCE="/var/www/mi-sitio"
#   BACKUP_FOLDER="/mnt/backups/mi-sitio-rsync"
#   ARCHIVE_FOLDER="/mnt/backups/mi-sitio-archives"

# 3. Ejecutar
./backup_manager.sh

# 4. Programar en cron (manual)
crontab -e
# Añadir: 0 2 * * * /ruta/a/backup_manager/backup_manager.sh
```

---

*Documentación generada a partir del código fuente en https://github.com/PlayWitIt/backup_manager (branch main, 4 commits, 2026-03-15).*
