# Plan de trabajo: Extension de backup_manager

> **Base:** PlayWitIt/backup_manager (https://github.com/PlayWitIt/backup_manager)  
> **Objetivo:** Soportar múltiples métodos (tar, rsync, zip, 7z) seleccionables por `.conf`, + subida externa con rclone.  
> **Fecha:** 2026-05-12

---

## Índice

- [1. Preguntas previas](#1-preguntas-previas)
  - [1.1. ¿Se puede usar 7z?](#11-se-puede-usar-7z)
  - [1.2. ¿Qué es rclone?](#12-qué-es-rclone)
- [2. Arquitectura propuesta](#2-arquitectura-propuesta)
  - [2.1. Variables en .conf](#21-variables-en-conf)
  - [2.2. Árbol de decisión del script](#22-árbol-de-decisión-del-script)
- [3. Plan de fases](#3-plan-de-fases)
  - [Fase 1: Métodos de compresion (tar, zip, 7z)](#fase-1-métodos-de-compresión-tar-zip-7z)
  - [Fase 2: Método rsync (incremental)](#fase-2-método-rsync-incremental)
  - [Fase 3: Subida externa con rclone](#fase-3-subida-externa-con-rclone)
  - [Fase 4: Verificación de integridad y rotación](#fase-4-verificación-de-integridad-y-rotación)
  - [Fase 5: Integración final y pruebas](#fase-5-integración-final-y-pruebas)

---

## 1. Preguntas previas

### 1.1. ¿Se puede usar 7z?

**Sí.** `7z` (p7zip) está disponible en Linux y se integra fácilmente en scripts Bash.

| Comando | Paquete | Formatos |
|---|---|---|
| `7z` | `p7zip-full` | 7z, zip, gzip, bzip2, tar, xz, etc. |
| `7za` | `p7zip` | Subconjunto (menos formatos) |
| `7zr` | `p7zip` | Solo 7z nativo |

Instalación:

```bash
sudo apt install p7zip-full
```

Uso en script:

```bash
# Comprimir directorio en .7z
7z a -t7z "$ARCHIVE_FOLDER/backup_$(date +%F).7z" "$SOURCE"

# Comprimir en .zip (con 7z)
7z a -tzip "$ARCHIVE_FOLDER/backup_$(date +%F).zip" "$SOURCE"

# Verificar integridad
7z t "$ARCHIVE_FOLDER/backup_$(date +%F).7z"
```

**Ventajas:** Mejor ratio de compresión que zip y gzip. Soporta múltiples formatos. Tiene verificación de integridad incorporada (`7z t`). Soporta cifrado AES-256.

**Desventaja:** No viene pre-instalado en la mayoría de sistemas (a diferencia de tar, gzip, zip).

### 1.2. ¿Qué es rclone?

**rclone** es un programa CLI para sincronizar archivos con servicios de almacenamiento en la nube. Funciona como "rsync para la nube" y actualmente soporta más de **40 proveedores**, incluyendo:

| Categoría | Proveedores |
|---|---|
| Nubes principales | Google Drive, Dropbox, OneDrive, iCloud Drive |
| S3 y compatibles | AWS S3, MinIO, DigitalOcean Spaces, Wasabi, Backblaze B2 |
| SFTP / FTP | Cualquier servidor SFTP o FTP |
| WebDAV | Nextcloud, ownCloud |
| Otras | Box, Mega, pCloud, Yandex Disk |

Instalación:

```bash
sudo -v ; curl https://rclone.org/install.sh | sudo bash
```

Uso típico para backup:

```bash
# Copiar archivos a SFTP
rclone copy /ruta/local/backups.zip remoteSFTP:/ruta/remota/

# Sincronizar con S3
rclone sync /ruta/local/backups.zip remoteS3:mibucket/backups/

# Subir a Google Drive
rclone copy /ruta/local/backups.zip remoteGD:Backups/
```

**Ventaja principal:** Una sola herramienta para cualquier destino (FTP, S3, SFTP, Google Drive, etc.). No necesitas `aws s3 cp`, `curl -T`, `scp`, etc. por separado. Ideal para la variable `REMOTE_TYPE` en los `.conf`.

---

## 2. Arquitectura propuesta

### 2.1. Variables en .conf

Cada archivo `.conf` tendrá estas variables:

```bash
# ── Método de backup ──────────────────────────────────
# Opciones: "tar" | "zip" | "7z" | "rsync"
METHOD="zip"

# ── Origen ───────────────────────────────────────────
SOURCE="/ruta/a/respaldar"

# ── Destinos locales ──────────────────────────────────
# Para rsync incremental (se omite si METHOD != rsync)
BACKUP_FOLDER="/ruta/backup-incremental"

# Para archivos comprimidos (tar, zip, 7z)
ARCHIVE_FOLDER="/ruta/archivos-comprimidos"

# ── Rotación ──────────────────────────────────────────
RETENTION_DAYS=7

# ── Subida externa ────────────────────────────────────
REMOTE_ENABLED="false"
REMOTE_DEST="remoteSFTP:/ruta/remota"
REMOTE_OPTS=""                  # flags extra para rclone

# ── Exclusiones ──────────────────────────────────────
EXCLUDE_PATTERNS="*.tmp *.log node_modules"
```

### 2.2. Árbol de decisión del script

```
main()
├── Cargar .conf (incluyendo METHOD)
├── Validar prerequisitos según METHOD
│   ├── tar   → tar
│   ├── zip   → zip
│   ├── 7z    → 7z (p7zip-full)
│   └── rsync → rsync
├── check_disk_space()
├── BACKUP según METHOD
│   ├── tar   → tar -czf archivo.tar.gz SOURCE
│   ├── zip   → zip -r archivo.zip SOURCE
│   ├── 7z    → 7z a -t7z archivo.7z SOURCE
│   └── rsync → rsync -av SOURCE/ BACKUP_FOLDER/
├── VERIFICACIÓN según METHOD
│   ├── tar   → tar -tzf
│   ├── zip   → zip -T
│   ├── 7z    → 7z t
│   └── rsync → rsync -av --dry-run (o diff)
├── ROTACIÓN según METHOD
│   ├── tar/zip/7z → find -mtime +RETENTION_DAYS -delete
│   └── rsync      → find -mtime +RETENTION_DAYS (en BACKUP_FOLDER)
├── SUBIDA externa (si REMOTE_ENABLED=true)
│   └── rclone copy LOCAL_PATH REMOTE_DEST
└── LOGGING
```

---

## 3. Plan de fases

### Fase 1: Métodos de compresión (tar, zip, 7z)

**Objetivo:** Añadir variable `METHOD` al script y a los `.conf`. Soportar `tar`, `zip` (ya disponible vía 7z o zip), `7z`.

#### Subtareas

| # | Tarea | Archivo |
|---|---|---|
| 1.1 | Añadir variable METHOD en example.conf y desarrollo-en-curso.conf default `METHOD="tar"` | `configs/*.conf` |
| 1.2 | Cargar METHOD desde config y validar valor permitido | `backup_manager.sh` |
| 1.3 | Implementar compresión con `tar -czf` | `backup_manager.sh` |
| 1.4 | Implementar compresión con `zip -r` | `backup_manager.sh` |
| 1.5 | Implementar compresión con `7z a -t7z` (o -tzip) | `backup_manager.sh` |
| 1.6 | Ajustar nombre de archivo según método (`.tar.gz` / `.zip` / `.7z`) | `backup_manager.sh` |

#### Test de Fase 1

```bash
# 1. Probar METHOD=tar
# 2. Probar METHOD=zip
# 3. Probar METHOD=7z
# 4. Verificar que el archivo se crea con la extensión correcta
# 5. Verificar que se puede extraer (tar -tzf, unzip -t, 7z t)
# 6. Probar METHOD inválido → error controlado
```

#### Criterio de éxito

Los tres formatos producen archivos válidos y pueden verificarse con sus respectivas herramientas.

---

### Fase 2: Método rsync (incremental)

**Objetivo:** Soportar `METHOD=rsync` para backup incremental, con el comportamiento original del script (rsync a BACKUP_FOLDER) más un archive opcional posterior.

#### Subtareas

| # | Tarea | Archivo |
|---|---|---|
| 2.1 | Implementar bloque rsync incremental similar al original pero condicionado a `METHOD=rsync` | `backup_manager.sh` |
| 2.2 | Si además hay ARCHIVE_FOLDER, comprimir BACKUP_FOLDER después del rsync usando el FORMAT_ARCHIVE | `backup_manager.sh` |
| 2.3 | Manejar código de salida 24 de rsync (ok) | `backup_manager.sh` |
| 2.4 | Exclusiones configurables via EXCLUDE_PATTERNS | `backup_manager.sh` |

#### Test de Fase 2

```bash
# 1. METHOD=rsync, primera ejecución → copia todo
# 2. METHOD=rsync, segunda ejecución → solo cambios
# 3. METHOD=rsync con ARCHIVE_FOLDER → rsync + archive comprimido
# 4. Verificar exclusiones funcionan
# 5. SOURCE no existe → error controlado
```

#### Criterio de éxito

rsync solo copia archivos nuevos/cambiados en ejecuciones sucesivas. Con ARCHIVE_FOLDER activo, genera también el comprimido.

---

### Fase 3: Subida externa con rclone

**Objetivo:** Añadir subida a servidor externo vía rclone, configurable por `.conf`.

#### Subtareas

| # | Tarea | Archivo |
|---|---|---|
| 3.1 | Añadir variables REMOTE_ENABLED, REMOTE_DEST, REMOTE_OPTS a example.conf | `configs/example.conf` |
| 3.2 | Implementar bloque post-backup: si REMOTE_ENABLED=true, ejecutar `rclone copy` | `backup_manager.sh` |
| 3.3 | Validar que rclone está instalado antes de intentar subida | `backup_manager.sh` |
| 3.4 | Logging de éxito/fallo de la subida | `backup_manager.sh` |
| 3.5 | Si la subida falla, el backup local no se elimina (seguridad) | `backup_manager.sh` |
| 3.6 | Añadir flag opcional REMOTE_DELETE_SOURCE para eliminar local post-subida exitosa | `backup_manager.sh` |

#### Test de Fase 3

```bash
# 1. REMOTE_ENABLED=false → no intenta subida
# 2. REMOTE_ENABLED=true + rclone no instalado → error explicativo
# 3. REMOTE_ENABLED=true + rclone configurado → archivo aparece en remoto
# 4. REMOTE_ENABLED=true + fallo de red → backup local preservado, error en log
# 5. Probar con destinos: SFTP local, S3, directorio local (loopback)
```

#### Criterio de éxito

Archivos comprimidos aparecen en el destino remoto. Falla de red no afecta backup local. Log refleja el resultado.

---

### Fase 4: Verificación de integridad y rotación

**Objetivo:** Cada método tiene su propia verificación post-creación. Rotación automática de archivos antiguos.

#### Subtareas

| # | Tarea | Archivo |
|---|---|---|
| 4.1 | Implementar verify_backup() que según METHOD ejecute: `tar -tzf`, `zip -T`, `7z t` | `backup_manager.sh` |
| 4.2 | Implementar rotate_backups() con RETENTION_DAYS, compatible con todos los métodos | `backup_manager.sh` |
| 4.3 | Añadir RETENTION_DAYS a example.conf (default 7) | `configs/example.conf` |
| 4.4 | Logging de archivos rotados | `backup_manager.sh` |

#### Test de Fase 4

```bash
# 1. Crear backup con METHOD=zip → zip -T pasa
# 2. Crear backup con METHOD=tar → tar -tzf pasa
# 3. Crear backup con METHOD=7z → 7z t pasa
# 4. Forzar archivo corrupto → verificación falla, alerta en log
# 5. RETENTION_DAYS=1 → archivo de ayer se elimina en próxima ejecución
```

#### Criterio de éxito

Cada método verifica su propio formato. Archivos antiguos se eliminan según RETENTION_DAYS.

---

### Fase 5: Integración final y pruebas

**Objetivo:** Unir todas las fases, crear suite de tests automatizada, documentación.

#### Subtareas

| # | Tarea | Archivo |
|---|---|---|
| 5.1 | Crear suite de tests completa (`test.sh`) que pruebe todos los métodos y combinaciones | `test.sh` |
| 5.2 | Crear configs de ejemplo para cada método en `configs/` | `configs/` |
| 5.3 | Documentar en README.md las nuevas variables y modos de uso | `README.md` |
| 5.4 | Dry-run / modo test sin efectos secundarios | `backup_manager.sh` |
| 5.5 | Preparar desarrollo-en-curso.conf con METHOD=zip y subida rclone activa | `configs/desarrollo-en-curso.conf` |

#### Test de Fase 5

```bash
# Suite completa (se ejecuta en orden)
bash test.sh

# Debe probar estas combinaciones mínimas:
# ┌──────────┬──────────┬──────────┐
# │ METHOD   │ Subida   │ Rotación │
# ├──────────┼──────────┼──────────┤
# │ tar      │ sí       │ sí       │
# │ zip      │ sí       │ sí       │
# │ 7z       │ sí       │ sí       │
# │ rsync    │ sí       │ sí       │
# │ rsync+tar│ sí       │ sí       │
# └──────────┴──────────┴──────────┘
```

#### Criterio de éxito

`bash test.sh` reporta 0 fallos. Los `.conf` de ejemplo son funcionales.

---

## 4. Estructura final del proyecto

```
backup_manager/
├── backup_manager.sh         # Script principal (modificado)
├── configs/
│   ├── example.conf          # Plantilla con todas las variables
│   ├── desarrollo-en-curso.conf  # Config activa para este workspace
│   └── ... (otros .conf por tarea)
├── logs/
│   └── backup.log
├── test.sh                   # Suite de pruebas automatizada
└── README.md                 # Documentación actualizada
```

---

## 5. Ejemplo de .conf final

```bash
# ── Método: tar | zip | 7z | rsync ────────────────────
METHOD="zip"

# ── Origen ────────────────────────────────────────────
SOURCE="/workspaces/generador"

# ── Rsync incremental (solo si METHOD=rsync) ──────────
BACKUP_FOLDER="/workspaces/backup-incremental"

# ── Archivo comprimido (tar, zip, 7z) ──────────────────
ARCHIVE_FOLDER="/workspaces/backup-archivos"

# ── Rotación ──────────────────────────────────────────
RETENTION_DAYS=7

# ── Subida externa vía rclone ─────────────────────────
REMOTE_ENABLED="true"
REMOTE_DEST="remoteSFTP:/backups/servidor1"
REMOTE_OPTS=""

# ── Exclusiones ──────────────────────────────────────
EXCLUDE_PATTERNS="*.tmp *.log node_modules .opencode"
```

---

*Documentación generada a partir del análisis de PlayWitIt/backup_manager, rclone.org, y p7zip.sourceforge.net.*
