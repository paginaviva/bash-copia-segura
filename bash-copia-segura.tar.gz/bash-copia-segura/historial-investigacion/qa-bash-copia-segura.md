# Q&A previo a implementación: bash-copia-segura

> **Fecha:** 2026-05-12  
> **Propósito:** Registrar preguntas, respuestas y decisiones de diseño antes de comenzar la implementación del nuevo repositorio independiente.

---

## Índice

- [1. Pregunta 1: Nombre del repositorio](#1-pregunta-1-nombre-del-repositorio)
- [2. Pregunta 2: Directorio de trabajo](#2-pregunta-2-directorio-de-trabajo)
- [3. Pregunta 3: Fases de implementación](#3-pregunta-3-fases-de-implementación)
- [4. Pregunta 4: Método de subida externa](#4-pregunta-4-método-de-subida-externa)
- [5. Pregunta 5: Licencia](#5-pregunta-5-licencia)
- [6. Decisiones de diseño adicionales](#6-decisiones-de-diseño-adicionales)

---

## 1. Pregunta 1: Nombre del repositorio

**Pregunta:** ¿Qué nombre tendrá el nuevo repositorio en GitHub?

**Respuesta:** `bash-copia-segura`

**Notas adicionales:**
- El código (comentarios, variables, funciones) se documentará en **inglés**
- La documentación para el usuario (README, manuales, guías) se redactará en **español (es-ES)**
- `bash-copia-segura` será también el nombre del repo en GitHub y del directorio de trabajo

---

## 2. Pregunta 2: Directorio de trabajo

**Pregunta:** ¿Dónde crear el directorio de trabajo dentro del workspace?

**Respuesta:** `/workspaces/bash-copia-segura/`

**Justificación:** Directorio hermano de `/workspaces/generador/`, fuera del proyecto existente para evitar mezcla. Aislado pero dentro del mismo workspace.

---

## 3. Pregunta 3: Fases de implementación

**Pregunta:** ¿Implementación completa de golpe o incremental?

**Respuesta:** **Todo de una vez** — Las 5 fases del plan se implementan completas sin entregas parciales.

**Alcance completo:**
- Fase 1: Métodos tar, zip, 7z seleccionables vía METHOD en .conf
- Fase 2: Método rsync (incremental) + archive opcional
- Fase 3: Subida externa vía rclone
- Fase 4: Verificación de integridad por método + rotación RETENTION_DAYS
- Fase 5: Suite de tests, dry-run, documentación

---

## 4. Pregunta 4: Método de subida externa

**Pregunta:** ¿Solo rclone o también alternativas nativas?

**Respuesta:** **Solo rclone** — rclone como interfaz única para cualquier destino externo (S3, SFTP, FTP, Google Drive, etc.).

---

## 5. Pregunta 5: Licencia

**Pregunta:** ¿Qué licencia usar para el nuevo repositorio?

**Respuesta:** **MIT** — Permisiva, estándar en proyectos open source pequeños.

---

## 6. Decisiones de diseño adicionales

| Decisión | Valor | Motivo |
|---|---|---|
| Lenguaje | Bash/Shell | Coherencia con el proyecto base |
| Archivos .conf por tarea | Sí | Múltiples tareas seleccionables (herencia de backup_manager) |
| Interacción | Menú interactivo + modo no-interactivo | Útil para cron |
| Métodos disponibles | tar, zip, 7z, rsync | Según plan aprobado |
| Subida externa | rclone | Único método, cualquier destino |
| Logging | Archivo timestamp + stdout | Trazabilidad |
| Tests | Bash script (`test.sh`) | Sin dependencias externas |
| Documentación usuario | Español (es-ES) | Según instrucción |
| Comentarios código | Inglés | Según instrucción |

---

*Documento generado previo a la implementación de `/workspaces/bash-copia-segura/`.*
