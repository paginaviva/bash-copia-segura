# bash-copia-segura — Handover para próximo agente

> **Estado:** Proyecto completo, 25/25 tests OK  
> **Repositorio destino:** https://github.com/tu-usuario/bash-copia-segura (aún no migrado)  
> **Origen:** Fork/refactor de https://github.com/PlayWitIt/backup_manager  

---

## Índice

- [1. Resumen del proyecto](#1-resumen-del-proyecto)
- [2. Estructura del package](#2-estructura-del-package)
- [3. Historial de investigación incluido](#3-historial-de-investigación-incluido)
- [4. Arquitectura](#4-arquitectura)
- [5. Lo que está implementado (5 fases)](#5-lo-que-está-implementado-5-fases)
- [6. Tests](#6-tests)
- [7. Pendiente / Próximos pasos](#7-pendiente--próximos-pasos)
- [8. Decisiones de diseño](#8-decisiones-de-diseño)
- [9. Cómo continuar el desarrollo](#9-cómo-continuar-el-desarrollo)
- [10. Referencias](#10-referencias)

---

## 1. Resumen del proyecto

**bash-copia-segura** es una herramienta CLI en Bash puro para realizar copias de seguridad con múltiples métodos (tar, zip, 7z, rsync), verificación de integridad, rotación automática y subida a servidores externos vía rclone.

Soporta **múltiples tareas** mediante archivos `.conf` independientes seleccionables por menú interactivo o vía `--config`.

El proyecto es 100% independiente (no depende del proyecto `generador`). Fue desarrollado como un repositorio hermano en `/workspaces/bash-copia-segura/` dentro del mismo workspace.

---

## 2. Estructura del package

```
bash-copia-segura/
├── copia-segura.sh          # Script principal (521 líneas)
├── configs/
│   ├── example.conf         # Plantilla con todas las variables documentadas
│   └── desarrollo.conf      # Config para workspace de desarrollo
├── docs/
│   ├── INSTALACION.md       # Guía de instalación (es-ES)
│   └── MANUAL-USO.md        # Manual de uso completo (es-ES)
├── test.sh                  # Suite de tests (25 tests)
├── README.md                # Documentación principal (es-ES)
├── LICENSE                  # MIT
├── logs/                    # Directorio de logs (se crea automáticamente)
│
├── historial-investigacion/  # Documentos históricos del proceso (ver sección 3)
│   ├── repos-bash-zip-backup.md
│   ├── guia-backup-script-sxnmgxr.md
│   ├── guia-backup-manager-playwitit.md
│   ├── evaluacion-repos-backup.md
│   └── plan-extension-backup-manager.md
│
└── AGENTS.md                # Este archivo
```

---

## 3. Historial de investigación incluido

La carpeta `historial-investigacion/` contiene los documentos generados durante la fase de investigación previa. Son **solo referencia histórica** para entender el proceso de decisión.

| Archivo | Contenido |
|---|---|
| `repos-bash-zip-backup.md` | Búsqueda en GitHub de 25 repos de backup en Bash |
| `guia-backup-script-sxnmgxr.md` | Análisis completo de sxnmgxr/backup-script |
| `guia-backup-manager-playwitit.md` | Análisis completo de PlayWitIt/backup_manager |
| `evaluacion-repos-backup.md` | Evaluación cruzada contra criterios: multi-config, ZIP, subida externa |
| `plan-extension-backup-manager.md` | Plan original de 5 fases aprobado por el usuario |

**Conclusión de la investigación:** Ningún repo existente cumplía los 3 criterios (multi-conf + ZIP + subida externa). Se optó por crear `bash-copia-segura` como proyecto independiente basado en la arquitectura de `backup_manager` pero con todas las extensiones necesarias.

---

## 4. Arquitectura

```
copia-segura.sh
├── CLI parser (--config, --dry-run, --list, --help)
├── Config selector (menú interactivo o --config)
├── source config.env
├── check_deps()
├── confirm()
├── check_disk_space()
├── run_backup()
│   ├── METHOD=tar  → tar -czf
│   ├── METHOD=zip  → zip -r
│   ├── METHOD=7z   → 7z a -t7z
│   └── METHOD=rsync → rsync -av + opcional tar.gz
├── verify_backup()
│   ├── tar  → tar -tzf
│   ├── zip  → unzip -t
│   └── 7z   → 7z t
├── rotate_backups()  → find -mtime +RETENTION_DAYS
├── remote_upload()   → rclone copy
└── list_backups()
```

### Árbol de decisión del método

```
METHOD en .conf
├── "tar"   → .tar.gz, verificación: tar -tzf
├── "zip"   → .zip,    verificación: unzip -t
├── "7z"    → .7z,     verificación: 7z t
└── "rsync" → dir incremental, + archive .tar.gz opcional
```

---

## 5. Lo que está implementado (5 fases)

| Fase | Descripción | Estado |
|---|---|---|
| 1 | Métodos tar/zip/7z seleccionables vía METHOD en .conf | ✓ |
| 2 | rsync incremental + archive comprimido opcional | ✓ |
| 3 | Subida externa vía rclone (cualquier destino: S3, SFTP, FTP, Google Drive...) | ✓ |
| 4 | Verificación de integridad por método + rotación RETENTION_DAYS | ✓ |
| 5 | Suite de tests (25), dry-run, CLI --help/--list/--config, docs | ✓ |

### Archivos .conf creados

| Archivo | Propósito |
|---|---|
| `configs/example.conf` | Plantilla documentada con todas las variables |
| `configs/desarrollo.conf` | Config para backup del workspace generador (METHOD=zip) |

---

## 6. Tests

```bash
cd bash-copia-segura
bash test.sh
```

Resultado actual: **25/25 passed, 0 failed**

Lo que prueba:

| # | Test |
|---|---|
| 1 | Script existe y es ejecutable |
| 2 | Archivos .conf existen |
| 3 | Comandos requeridos instalados (tar, zip, find, date) |
| 4 | METHOD=tar: backup completo, archivo válido |
| 5 | METHOD=zip: backup completo, archivo válido, exclusiones funcionan |
| 6 | METHOD=7z: backup completo (si 7z instalado) |
| 7 | METHOD=rsync: backup completo, archivos destino presentes |
| 8 | EXCLUDE_PATTERNS en example.conf |
| 9 | REMOTE_ENABLED y REMOTE_DEST en example.conf |
| 10 | CLI: --help, --list, --dry-run + --config |
| 11 | Método inválido: error controlado |
| 12 | Sintaxis Shell de ambos scripts |

---

## 7. Pendiente / Próximos pasos

### Antes del primer release

- [ ] **Migrar a GitHub:** Crear repo `bash-copia-segura` y hacer push
- [ ] **Verificar rclone:** Instalar rclone en entorno de pruebas y testear subida real
- [ ] **Instalar p7zip-full:** Ejecutar tests con METHOD=7z
- [ ] **Prueba con datos reales:** Backup del workspace completo con METHOD=zip + exclusión de node_modules
- [ ] **Configurar cron:** Decidir frecuencia y añadir crontab

### Mejoras futuras (post-MVP)

| Sugerencia | Prioridad | Esfuerzo |
|---|---|---|
| Notificaciones vía webhook (Slack/Discord/Telegram) | Media | 1 día |
| Cifrado GPG de los archivos comprimidos | Media | 1 día |
| Backup de MySQL/PostgreSQL pre-archive | Alta | 2 días |
| Systemd timer como alternativa a cron | Baja | 1 día |
| Modo `--quiet` para cron (solo errores a stdout) | Baja | 0.5 día |
| Test de integración de subida rclone | Media | 1 día |
| Parallel upload con rclone (varios hilos) | Baja | 0.5 día |

### Bugs conocidos

- Ninguno conocido. Los 25 tests pasan.

---

## 8. Decisiones de diseño

| Decisión | Valor | Justificación |
|---|---|---|
| Lenguaje | Bash | Independencia, cero dependencias de runtime |
| Comentarios en código | Inglés | Estándar en código abierto |
| Documentación de usuario | Español (es-ES) | Requisito del usuario |
| Métodos disponibles | tar, zip, 7z, rsync | Aprobado en plan de 5 fases |
| Subida externa | Solo rclone | Un interfaz para cualquier destino |
| Archivos .conf por tarea | Múltiples en `configs/` | Herencia de backup_manager |
| Interacción | Menú + `--config` | Modo interactivo y para cron |
| Logging | Archivo + stdout con `tee` | Trazabilidad sin ocultar salida |
| Tests | Bash script (`test.sh`) | Sin dependencias externas |
| Licencia | MIT | Aprobado por el usuario |

---

## 9. Cómo continuar el desarrollo

### Setup inicial

```bash
# El proyecto ya está en /workspaces/bash-copia-segura/
cd /workspaces/bash-copia-segura

# Si es desde el package comprimido
tar -xzf bash-copia-segura.tar.gz
cd bash-copia-segura

# Verificar estado
bash test.sh

# Probar backup real con METHOD=zip
echo "y" | ./copia-segura.sh --config configs/desarrollo.conf
```

### Flujo de trabajo recomendado

1. Leer `historial-investigacion/` para contexto
2. Leer `docs/MANUAL-USO.md` para entender el funcionamiento
3. Revisar `AGENTS.md` (este archivo)
4. Ejecutar `bash test.sh` para verificar estado actual
5. Hacer cambios, ejecutar tests, repetir
6. Cuando el usuario lo indique, migrar a GitHub

### Migración a GitHub

```bash
# En el momento que el usuario lo indique:
cd /workspaces/bash-copia-segura
git init
git add .
git commit -m "Initial commit: bash-copia-segura v1.0"
git remote add origin https://github.com/tu-usuario/bash-copia-segura.git
git push -u origin main
```

---

## 10. Referencias

- **Repo base original:** https://github.com/PlayWitIt/backup_manager
- **Documentación rclone:** https://rclone.org/docs/
- **Documentación p7zip:** https://p7zip.sourceforge.net/
- **Decisiones de diseño:** `historial-investigacion/plan-extension-backup-manager.md`

---

*Handover generado el 2026-05-12 por el agente original.*
